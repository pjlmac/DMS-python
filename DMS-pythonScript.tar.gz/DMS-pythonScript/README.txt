Enclosed in this folder includes components of a Python script that I have been 
using in my current research that is free to be distributed. In this script, I
am trying to determine which nucleotides in my desired transcript (MALAT1)
correspond to a certain number of returns from a DMS-seq dataset.

I have written this script in Python3.

Aside from default Python modules (sys and pandas), BioPython is needed to parse
the fasta file input.

The enclosed Fasta file is a selection of data from a significantly larger
Fasta file from the hg19 human genome.

The enclosed CSV file is a selection of data from the DMS-seq dataset that I use
in my analysis.

The enclosed InputDMS file is an accession lookup file that can be edited to 
examine for a desired accession number. For this script in its current form, 
only one accession can be entered for the Python script to function.