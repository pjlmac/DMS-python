#import relevant libraries; Biopython is a required component for this script; written for Python3
import sys
import pandas as pd
from Bio import SeqIO

#test for presence of variables in command line
CutOff=sys.argv[0]
InputFile=sys.argv[1]
Accession=sys.argv[2]
try:
    CutOff=sys.argv[0]
except IndexError:
    print("No numerical cutoff given.")
    sys.exit()
try:
    InputFile=sys.argv[1]
except IndexError:
    print ("No input file is found.")
    sys.exit()
try:
    Accession=sys.argv[2]
except IndexError:
    print("No accession number given.")
    sys.exit()

#open/close is to search for the desired nucleotide sequences 
outputFasta = open('OutputSeqs.fasta','w+')
InputData = open('InputFile').read().splitlines(True)

#the for loop below is specific for BioPython. 
for FastaFind in SeqIO.parse('lncRNAFasta.fasta','fasta'):
    for seqname in InputData:
        name = seqname.strip()
        if FastaFind.id == name:
            SeqIO.write(FastaFind,outputFasta,'fasta')
outputFasta.close()

#the below code removes the accession number return from OutputSeqs.fasta- comment out if this accession number is desired
#the line removal is needed for the rest of the PythonScript
with open ('OutputSeqs.fasta', 'r') as fin:
    data = fin.read().splitlines()
with open ('OutputSeqs.fasta','w') as fout:
    fout.writelines(data[1:])

#the below code searches for the DMS-seq hits within a desired RNA with a desired numerical cutoff 
DMSseq=pd.read_csv("DMSseq.csv")
DMSseq.shape
DMSseq.columns

#Search for desired transcript ID
AccessionFind= DMSseq.Transcript_ID.str.contains('Accession')
InitialDMSProcess=(DMSseq[AccessionFind]['Transcript_position_number'].where(DMSseq[AccessionFind]['DMS-seq_count_number'] > 'CutOff'))
ProcessedDMSseq=InitialDMSProcess.dropna(how='any')

#write-out to a csv for additional analysis
ProcessedDMSseq.to_csv('ProcessedDMSseq.csv',',', header=['Transcript_Position'])

#add nucleotide identity from desired RNA transcript to each position in ProcessedDMSseq file
DMScounts = pd.read_csv('ProcessedDMSseq.csv')
fa = open('OutputSeqs.fasta')
fa_contents = fa.read()
fa.close()
DMScounts['Nucleotide_ID']=''
for i in range (0,len(DMScounts)):
    DMScounts.iloc[i,2]=fa_contents[DMScounts.iloc[i,0]]
DMScounts.to_csv('FinalDMSseq.csv', ',', header=['Input_DMS_seq_line_number', 'Transcript_Position', 'Nucleotide_ID'])